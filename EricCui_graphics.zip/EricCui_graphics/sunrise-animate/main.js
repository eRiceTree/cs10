'use strict';


// set up the canvas and graphic context
let cnv = document.getElementById('myCanvas');
let ctx = cnv.getContext('2d');
cnv.width = 400
cnv.height = 400

let cloud = document.getElementById('cloud')


let CloudLeftX = 140;
let CloudRightX = 190;
let SunY = 300;
let frameCount = 0;
let SunSize = 20;
let SunR = 255;
let SunG = 0;
requestAnimationFrame(loop);
function loop() {
    frameCount++;

    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, cnv.width, cnv.height);

    CloudLeftX--;
    CloudRightX++;
    if (SunSize < 60) {
        SunY--;
        SunSize += 0.2;
        SunG += 1.5;
    }

    // lets draw something with graphic context (ctx)
    ctx.fillStyle = 'blue';
    ctx.fillRect(0, 0, 400, 400); //draw a line rectangle

    //circles
    ctx.lineWidth = 2;
    ctx.fillStyle = 'rgb('+ SunR + ','+ SunG + ',0)';
    ctx.beginPath();
    ctx.arc(200, SunY, SunSize, 0, 2 * Math.PI);
    ctx.fill();

    ctx.fillStyle = 'green';
    ctx.fillRect(0, 300, 400, 400); //draw a line rectangle


    ctx.lineWidth = 2;
    ctx.fillStyle = 'green';
    ctx.beginPath();
    ctx.arc(50, 500, 20, 0, 2 * Math.PI);
    ctx.fill();

    ctx.drawImage(cloud, CloudLeftX, 120);
    ctx.drawImage(cloud, CloudRightX, 100);

    
requestAnimationFrame(loop);
}




















