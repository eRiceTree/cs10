'use strict';


console.log('Hello Console!');

//setup canvas and graphics context

let cnv = document.getElementById('myCanvas');
let ctx = cnv.getContext('2d');

cnv.width = 600;
cnv.height = 400;

//global variables

let rectX = 240;
let rectY = 160;
let rectSizeX = 100;
let rectSizeY = 100;
let rectR = 122;
let rectG = 122;
let rectB = 122;
let frameCount = 0;
let animate = false;
//drawing a square


requestAnimationFrame(loop);
function loop() {
    frameCount++;

    if (animate) {
        rectX = rectX + Math.random()*20 - 10;
        rectY = rectY + Math.random()*20 - 10;
        rectSizeX = rectSizeX + Math.random()*20 - 10;
        rectSizeY = rectSizeY + Math.random()*20 - 10;
        rectR = rectR + Math.random()*100 - 50;
        rectB = rectB + Math.random()*100 - 50;
        rectG = rectG + Math.random()*100 - 50;  
    }


    
    ctx.fillStyle = 'white';
    ctx.fillRect(0,0,cnv.width,cnv.height);

    ctx.fillStyle = 'rgb('+ rectR + ','+ rectG + ','+ rectB + ')';
    ctx.fillRect(rectX,rectY,rectSizeX,rectSizeY);
    requestAnimationFrame(loop);
    
}


//event stuff

document.addEventListener('click',mouseclickHandler);
document.addEventListener('keydown',keydownHandler);

function mouseclickHandler() {
    if (animate) {
    animate = false;
} else {
    animate = true;
}
}


function keydownHandler() {
    console.log(event.code);
    if (event.code == "Space")
     rectX = 290 - rectSizeX * .5;
     rectY = 210 - rectSizeY * .5;
}