# windy-day-start
Start Code for Web Graphics Windy Day Assignment
