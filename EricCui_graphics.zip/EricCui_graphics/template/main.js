'use strict';


console.log('Hello Console!');





document.getElementById('para1').addEventListener('click', clickHandler);document

function clickHandler() {
    console.log('Click Event');
    document.getElementById('main-heading').innerHTML = '';
    document.getElementById('img1').src = '';
    document.getElementById('link1').href = ""
    document.getElementById('para1').style.fontFamily = '';
    document.getElementById('para1').style.fontVariant = '';

    document.getElementById('li2').classList.toggle('center');
}

function dblclickEvent() {
    console.log('Double-Click Event');
}

function mousedownHandler() {
    console.log('Mouse Down Event');
}

function mouseupHandler() {
    console.log('Mouse Up Event');
}


function scrollHandler() {
    console.log('Scroll Event');
}

function keyupHandler() {
    console.log('Key Up Event');
}

function keydownHandler() {
    console.log('Key Down Event');
}