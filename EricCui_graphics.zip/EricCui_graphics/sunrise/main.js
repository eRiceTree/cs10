'use strict';


// set up the canvas and graphic context
let cnv = document.getElementById('myCanvas');
let ctx = cnv.getContext('2d');
cnv.width = 400
cnv.height = 400

let cloud = document.getElementById('cloud')




// lets draw something with graphic context (ctx)
ctx.fillStyle = 'blue';
ctx.fillRect(0,0,400,400); //draw a line rectangle


//circles
ctx.lineWidth = 2;
ctx.fillStyle = 'red';
ctx.beginPath();
ctx.arc(200,300,20,1000, 2* Math.PI);
ctx.fill();

ctx.fillStyle = 'green';
ctx.fillRect(0,300,400,400); //draw a line rectangle


ctx.lineWidth = 2;
ctx.fillStyle = 'green';
ctx.beginPath();
ctx.arc(50,500,20,0,2 * Math.PI)
ctx.fill();

ctx.drawImage(cloud, 140, 120);
ctx.drawImage(cloud, 190, 100);

























