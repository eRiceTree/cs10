'use strict';


console.log('Hello Console!');

//setup canvas and graphics context

let cnv = document.getElementById('myCanvas');
let ctx = cnv.getContext('2d');

cnv.width = 600;
cnv.height = 400;

//global variables

let rectX = 240;
let rectY = 160;
let rectSizeX = 100;
let rectSizeY = 100;
let rectR = 122;
let rectG = 122;
let rectB = 122;
let frameCount = 0;
let animate = false;
let mousePressed = false;
let mouseX,mouseY,pmouseX,pmouseY;
let size = 5;
let penColor = 'black';
//drawing a square


requestAnimationFrame(loop);
function loop() {
    frameCount++;


    if (mousePressed) {
        ctx.strokeStyle = penColor;
        ctx.beginPath();
        ctx.moveTo(pmouseX,pmouseY);
        ctx.lineTo(mouseX,mouseY);
        ctx.stroke();
    }


    
    //ctx.fillStyle = 'rgb('+ rectR + ','+ rectG + ','+ rectB + ')';
    //ctx.fillRect(rectX,rectY,rectSizeX,rectSizeY);
    requestAnimationFrame(loop);
    
}


//event stuff

//document.addEventListener('click',mouseclickHandler);
document.addEventListener('mousedown',mousedownHandler);
document.addEventListener('mouseup',mouseupHandler);
document.addEventListener('keydown',keydownHandler);
document.addEventListener('mousemove',mousemoveHandler);

function mousedownHandler() {
    mousePressed = true;
}
function mouseupHandler() {
    mousePressed = false;
}

function keydownHandler(event) {
    console.log(event.code);
    if (event.code == "Space") {
    ctx.fillStyle = 'white';
    ctx.fillRect(0,0,cnv.width,cnv.height);
    } else if (event.code == 'ArrowUp') {
        size++;
    } else if (event.code == 'ArrowDown') {
        size--;
    } else if (event.code == 'Digit1') {
        penColor = 'red';
    } else if (event.code == 'Digit2') {
        penColor = 'blue';
    } else if (event.code == 'Digit3') {
        penColor = 'green';
    } 

}

function mousemoveHandler(event) {
    pmouseX = mouseX;
    pmouseY = mouseY;


    let cnvRect = cnv.getBoundingClientRect();
    mouseX = event.x - cnvRect.x;
    mouseY = event.y - cnvRect.y;

    

}

//button events

document.getElementById("redBtn").addEventListener("click",setRed);

function setRed() {
    penColor = 'red';
}