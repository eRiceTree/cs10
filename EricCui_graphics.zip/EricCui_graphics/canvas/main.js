'use strict';


// set up the canvas and graphic context
let cnv = document.getElementById('myCanvas');
let ctx = cnv.getContext('2d');
cnv.width = 800
cnv.height = 600

let edge = document.getElementById('edge')




// lets draw something with graphic context (ctx)
ctx.strokeStyle = 'rgb(30, 20, 0)';
ctx.strokeRect(50,20,150,30); //draw a line rectangle

ctx.fillStyle = 'green';
ctx.fillRect(225,50,100,100); //draw a filled square

//set the outline(stroke) and fill colors
//use any valid css colors: name, rgb(), rgba(hex #FF0033)

//draw text
ctx.font = '42px Comic Sans MS';
ctx.fillStyle = 'red';
ctx.fillText('Hello World',400,50);

//outline of text
ctx.font = '70px Arial';
ctx.strokeStyle = 'blue';
ctx.strokeText('helloCanvas', 400, 400)

// draw lines
ctx.lineWidth = 40;
ctx.beginPath();
ctx.moveTo(500,250);
ctx.lineTo(700,200);
ctx.stroke();

//polygon
ctx.fillStyle = 'cyan';
ctx.strokeStyle = 'cyan';
ctx.beginPath();
ctx.moveTo(200,250);
ctx.lineTo(600,300);
ctx.lineTo(100,400);
ctx.closePath();
ctx.fill();

ctx.lineWidth = 2;
ctx.fillStyle = 'green';
ctx.beginPath();
ctx.arc(50,500,20,0,2 * Math.PI)
ctx.fill();


//circles
ctx.lineWidth = 5;
ctx.strokeStyle = 'blue';
ctx.beginPath();
ctx.arc(100,500,50,0, 2* Math.PI);
ctx.stroke();

ctx.lineWidth = 2;
ctx.fillStyle = 'green';
ctx.beginPath();
ctx.arc(250,500,20,0, Math.PI)
ctx.fill();

ctx.drawImage(edge, 200, 200);
ctx.drawImage(edge, 216, 200);

























